﻿namespace MVC_Interview_C_Sharp.SOLID.OCP
{
    #region OCP
    public class Customer
    {
        private int _CustType;

        public int CustType
        {
            get { return _CustType; }
            set { _CustType = value; }
        }

        public double getDiscount(double TotalSales)
        {
            if (_CustType == 1)
            {
                return TotalSales - 100;
            }
            else
            {
                return TotalSales - 50;
            }
        }
    }

    #endregion
}






































































#region OCP
//class Customer
//{
//    public virtual double getDiscount(double TotalSales)
//    {
//        return TotalSales;
//    }
//}

//class SilverCustomer : Customer
//{
//    public override double getDiscount(double TotalSales)
//    {
//        return base.getDiscount(TotalSales) - 50;
//    }
//}

//class GoldCustomer : SilverCustomer
//{
//    public override double getDiscount(double TotalSales)
//    {
//        return base.getDiscount(TotalSales) - 100;
//    }
//}
#endregion