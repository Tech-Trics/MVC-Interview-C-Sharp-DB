﻿using System;

namespace MVC_Interview_C_Sharp.SOLID.ISP
{
    interface IDiscount
    {
        double getDiscount(double TotalSales);
    }


    interface IDatabase
    {
        void Add(); // old client are happy with these.

        //Now let’s say some new clients come up with a demand saying that we also want a method which will help us to “Read” customer data.
        //So developers who are highly enthusiastic would like to change the “IDatabase” interfaceas shown below.
        void Read(); // Added for new clients.
    }

    class Enquiry : IDiscount
    {
        public double getDiscount(double TotalSales)
        {
            return TotalSales - 5;
        }
    }   
}

























#region ISP
/*

interface IDatabaseV1 : IDatabase // Gets the Add method
{
    Void Read();
}

class CustomerwithRead : IDatabase, IDatabaseV1
{

    public void Add()
    {
	    Customer obj = new Customer();
        Obj.Add();
    }
	
    public void Read()
	{
	    // Implements  logic for read
    }
}


//So the old clients will continue using the “IDatabase” interface while new client can use “IDatabaseV1” interface.  

IDatabase i = new Customer(); // 1000 happy old clients not touched
i.Add();

IDatabaseV1 iv1 = new CustomerWithread(); // new clients
Iv1.Read();

 */

#endregion